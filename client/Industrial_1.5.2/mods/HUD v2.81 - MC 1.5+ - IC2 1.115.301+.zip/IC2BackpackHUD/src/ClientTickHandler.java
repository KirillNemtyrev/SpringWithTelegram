package IC2BackpackHUD;

import ic2.api.item.IElectricItem;
import java.util.EnumSet;
import org.lwjgl.opengl.GL11;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.RenderEngine;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.IItemRenderer;
import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.ITickHandler;
import cpw.mods.fml.common.TickType;

public class ClientTickHandler implements ITickHandler
{
	private static Minecraft minecraft = FMLClientHandler.instance().getClient();
	private static RenderItem itemRenderer = new RenderItem();
	int scaledWidth, scaledHeight;
	long[] elapsedDrawTime = new long[4];
	int[] currentCharge = new int[4], lastCharge = new int[4];
	boolean[] isCharging = new boolean[4], isLowPower = new boolean[4];
	final byte pixelNudge = 1;
	final byte bgHeight = 21, bgWidth = 18;

	@Override
	public void tickStart(EnumSet<TickType> type, Object... tickData) {}

	@Override
	public void tickEnd(EnumSet<TickType> type, Object... tickData)
	{
		if (type.equals(EnumSet.of(TickType.RENDER)))
		{			
			GuiScreen guiscreen = Minecraft.getMinecraft().currentScreen;
			if (guiscreen == null)
				onTickInGame();
		}
	}

	public void onTickInGame()
	{
		ScaledResolution scaledResolution = new ScaledResolution(minecraft.gameSettings, minecraft.displayWidth, minecraft.displayHeight);
		scaledWidth = scaledResolution.getScaledWidth();
		scaledHeight = scaledResolution.getScaledHeight();

		/**
		 * Armor Inventory Key
		 *
		 * 	Helmet 		= armorInventory[3]
		 * 	Chestplate 	= armorInventory[2]
		 * 	Leggings 	= armorInventory[1]
		 * 	Boots 		= armorInventory[0]
		 */

		ItemStack[] armorInventory = minecraft.thePlayer.inventory.armorInventory;
		boolean[] isValidArmor = new boolean[4];
		boolean hasValidArmor = false;
		byte armorPiecesWorn = 0;

		// Detect valid armor pieces worn
		for (byte count = 0; count < 4; count++) {
			if (armorInventory[count] != null) {
				if ((IC2BackpackHUD.ic2Loaded && armorInventory[count].getItem() instanceof IElectricItem) ||
					(IC2BackpackHUD.showNonElectricItems && armorInventory[count].getItem().isDamageable() && armorInventory[count].getItemDamage() >= 0)) {
					armorPiecesWorn++;
					isValidArmor[count] = true;
					hasValidArmor = true;
				}
			}
		}

		// Continue if valid armor item(s) equipped
		if (hasValidArmor) {

			// Assign draw coordinates to armor pieces
			int[] xCoord = new int[4];
			int[] yCoord = new int[4];
			for (byte count = 3, tempPiecesWorn = armorPiecesWorn; count >= 0; count--) {
				if (isValidArmor[count]) {
					switch(IC2BackpackHUD.hudPosition) {
					// Vertical, Top-Left Corner
					case 0: {
						xCoord[count] = pixelNudge * 3;
						yCoord[count] = pixelNudge - 16 + (((armorPiecesWorn + 1) - tempPiecesWorn--) * bgHeight);
						break;
					}
					// Vertical, Bottom-Left Corner
					case 1: {
						xCoord[count] = pixelNudge * 3;
						yCoord[count] = scaledHeight - 16 - (pixelNudge * 3) - ((tempPiecesWorn-- - 1) * bgHeight);
						break;
					}
					// Horizontal, Left of Hotbar
					case 2: {
						xCoord[count] = (scaledWidth / 2 - 92) - tempPiecesWorn-- * bgWidth;
						yCoord[count] = scaledHeight - 16 - pixelNudge * 2;
						break;
					}
					// Horizontal, Right of Hotbar
					case 3: {
						xCoord[count] = (scaledWidth / 2 + 94) + (armorPiecesWorn - tempPiecesWorn--) * bgWidth;
						yCoord[count] = scaledHeight - 16 - pixelNudge * 2;
						break;
					}
					// Vertical, Bottom-Right Corner
					case 4: {
						xCoord[count] = scaledWidth - pixelNudge - bgWidth;
						yCoord[count] = scaledHeight - 16 - (pixelNudge * 3) - ((tempPiecesWorn-- - 1) * bgHeight);
						break;
					}
					// Vertical, Top-Right Corner
					case 5: {
						xCoord[count] = scaledWidth - pixelNudge - bgWidth;
						yCoord[count] = pixelNudge - 16 + (((armorPiecesWorn + 1) - tempPiecesWorn--) * bgHeight);
						break;
					}
					}
				}
			}
			
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
			
			// Draw armor pieces
			if (isValidArmor[3] && IC2BackpackHUD.showHelmetItems) drawArmor(3, xCoord[3], yCoord[3]);
			if (isValidArmor[2] && IC2BackpackHUD.showChestplateItems) drawArmor(2, xCoord[2], yCoord[2]);
			if (isValidArmor[1] && IC2BackpackHUD.showLeggingItems) drawArmor(1, xCoord[1], yCoord[1]);
			if (isValidArmor[0] && IC2BackpackHUD.showBootItems) drawArmor(0, xCoord[0], yCoord[0]);
			
			GL11.glDisable(GL11.GL_BLEND);
			GL11.glPopMatrix();			
		}
	}

	@Override
	public EnumSet<TickType> ticks()
	{
		return EnumSet.of(TickType.RENDER, TickType.CLIENT);
	}

	@Override
	public String getLabel() { return null; }
	
	/**
	 * Return item damage as an integer value between 0 and 14
	 */
	int getChargeLevel(ItemStack armor)
	{
		int defaultCharge = (int) Math.round(13.0D - (double)armor.getItemDamageForDisplay() * 13.0D / (double)armor.getMaxDamage());
		
        if (armor.isItemDamaged()) {
        	/*
        	 * Vanilla item damage level is computed using a 13-value range.  This introduces rounding
        	 * errors for low max damage items when scaling to a 15-value range.  This returns the
        	 * correct zero-value item charge according to default item damage level checks.
        	 */
        	if (defaultCharge == 0) {
        		return 0;
        	} else {
        		return (int) Math.round(15.0D - (double)armor.getItemDamageForDisplay() * 15.0D / (double)armor.getMaxDamage());
        	}
        } else {
        	return 14;
        }
	}
	
    /**
     * Draws a textured rectangle at the stored z-value. Args: x, y, u, v
     */
    public void drawTexturedModalRect(int x, int y, int z, int par4, int u, int v)
    {
        float f = 0.00390625F;
        float f1 = 0.00390625F;
        Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV((double)(x + 0), (double)(y + v), 0, (double)((float)(z + 0) * f), (double)((float)(par4 + v) * f1));
        tessellator.addVertexWithUV((double)(x + u), (double)(y + v), 0, (double)((float)(z + u) * f), (double)((float)(par4 + v) * f1));
        tessellator.addVertexWithUV((double)(x + u), (double)(y + 0), 0, (double)((float)(z + u) * f), (double)((float)(par4 + 0) * f1));
        tessellator.addVertexWithUV((double)(x + 0), (double)(y + 0), 0, (double)((float)(z + 0) * f), (double)((float)(par4 + 0) * f1));
        tessellator.draw();
    }
	
	/**
	 * Draw armor item starting at given coordinate
	 */
	void drawArmor(int armorNum, int xCoord, int yCoord)
	{
		ItemStack armorSlot = minecraft.thePlayer.inventory.armorInventory[armorNum];

		// Get item charge or health
		int chargeLevel = getChargeLevel(armorSlot);
		
		// Set charge level color properties used for background and item health bar
		float red = 1.0F - (float)(chargeLevel / 14.0F);
		float green = (float)(chargeLevel / 14.0F);

		// Draw armor background
		if (IC2BackpackHUD.showBackground) {
			minecraft.renderEngine.bindTexture("/mods/IC2BackpackHUD/render/textures.png");
			GL11.glColor4f(isCharging[armorNum] ? 1.0F : red, isCharging[armorNum] ? 1.0F : green, 0.0F, 1.0F);
			drawTexturedModalRect(xCoord - 1, yCoord - 4, 16, 0, bgWidth, bgHeight);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		}

		// Draw armor item
		int armorColor = armorSlot.getItem().getColorFromItemStack(armorSlot, 0);
		if (armorColor > 0) {
			float tempRed = (float)(armorColor >> 16 & 255) / 255.0F;
			float tempGreen = (float)(armorColor >> 8 & 255) / 255.0F;
			float tempBlue = (float)(armorColor & 255) / 255.0F;
			GL11.glColor4f(1.0F * tempRed, 1.0F * tempGreen, 1.0F * tempBlue, 1.0F);
		}
		minecraft.renderEngine.bindTexture("/gui/items.png");
		itemRenderer.renderIcon(xCoord, yCoord - 2, armorSlot.getIconIndex(), 16, 16);
		minecraft.renderEngine.bindTexture("/mods/IC2BackpackHUD/render/textures.png");

		// Identify armor charge status every half second
		int elapsedTime = (int) (System.nanoTime() - elapsedDrawTime[armorNum]);
		if (elapsedTime > 500000000) {
			
			isCharging[armorNum] = false;
			isLowPower[armorNum] = false;

			if (IC2BackpackHUD.ic2Loaded && IC2BackpackHUD.showChargingFlasher) {
				if (armorSlot.getItem() instanceof IElectricItem) {

					if (armorSlot.stackTagCompound != null && armorSlot.stackTagCompound.hasKey("charge")) {
						currentCharge[armorNum] = armorSlot.stackTagCompound.getInteger("charge");
					}

					if (currentCharge[armorNum] > lastCharge[armorNum]) {
						isCharging[armorNum] = true;
					}

					lastCharge[armorNum] = currentCharge[armorNum];
				}
			}

			// Low power indicator status
			if (IC2BackpackHUD.showLowPowerFlasher) {
				if (chargeLevel <= 2) {
					isLowPower[armorNum] = true;
				}
			}

			elapsedDrawTime[armorNum] = System.nanoTime();
		}
		
		// Draw status icon
		if (isLowPower[armorNum] || isCharging[armorNum]) {
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F - (chargeLevel == 0 ? 0 : (Math.abs(elapsedTime - 250000000) / 250000000.0F)));
			drawTexturedModalRect(xCoord, yCoord - 3, 0, (isCharging[armorNum] ? 16 : 0), 16, 16);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		}
		
		/*
		 *  Draw charge background and charge level
		 */
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glBegin(GL11.GL_QUADS);

		// Charge background
		GL11.glColor4f(0.03515625F, 0.0625F, 0.046875F, 1.0F);
		GL11.glVertex3d(xCoord + 1, yCoord + 13, 0);
		GL11.glVertex3d(xCoord + 1, yCoord + 13 + 2, 0);
		GL11.glVertex3d(xCoord + 15, yCoord + 13 + 2, 0);
		GL11.glVertex3d(xCoord + 15, yCoord + 13, 0);
		
		// Depleted charge bar
		GL11.glColor4f(0.15625F, 0.24609375F, 0, 1.0F);
		GL11.glVertex3d(xCoord + 1, yCoord + 13, 0);
		GL11.glVertex3d(xCoord + 1, yCoord + 13 + 1, 0);
		GL11.glVertex3d(xCoord + 14, yCoord + 13 + 1, 0);
		GL11.glVertex3d(xCoord + 14, yCoord + 13, 0);
		
		// Charge bar
		GL11.glColor4f(isCharging[armorNum] ? 1.0F : red, isCharging[armorNum] ? 1.0F : green, 0.0F, 1.0F);
		GL11.glVertex3d(xCoord + 1, yCoord + 13, 0);
		GL11.glVertex3d(xCoord + 1, yCoord + 13 + 1, 0);
		GL11.glVertex3d(xCoord + 1 + chargeLevel, yCoord + 13 + 1, 0);
		GL11.glVertex3d(xCoord + 1 + chargeLevel, yCoord + 13, 0);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		
		GL11.glEnd();
		GL11.glEnable(GL11.GL_TEXTURE_2D);
	}
}